  $('.btnHide').click(function() {
    $('.odlomciHiSh').hide()
  })

  $('.btnShow').click(function() {
    $('.odlomciHiSh').show()
  })

  $('.btnToggle').click(function() {
    $('.odlomciToggle').toggle()
  })
  
  $('.btnClick').click(function() {
    alert('jQuery click() događaj')
  })

  $('.btnToggle').click(function() {
    $('.odlomciSlideToggle').toggle();
  })

  $('.btnAnimate').click(function() {
    $(".primjer").animate({left: '250px'});
  })

  var x = 0;
  $(document).ready(function(){
    $(".divprimjer").scroll(function(){
      $(".spanScroll").text( x+= 1);
    });
  });




