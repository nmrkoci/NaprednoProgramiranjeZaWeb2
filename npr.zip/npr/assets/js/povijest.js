$('#alldivs2005').hide()
$('.gumb2005').click(function() {
    $('#alldivs2005').toggle()
  })
  
  $('#alldivs2007').hide()
  $('.gumb2007').click(function() {
      $('#alldivs2007').toggle()
    })
    
    $('#alldivs2016').hide()
  $('.gumb2016').click(function() {
      $('#alldivs2016').toggle()
    })
    
    $('#alldivssad').hide()
    $('.gumbsad').click(function() {
        $('#alldivssad').toggle()
      })
    
      