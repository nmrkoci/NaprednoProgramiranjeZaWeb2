let header = document.querySelector('header');

window.addEventListener('scroll', function(){
    yPozicija = window.scrollY;

    if(yPozicija > '0') {
        header.style.boxShadow = '1px 1px 3px #d1d1d1';
    }
    
    else {
        header.style.boxShadow = '1px 1px 3px #fff';
    }
});

let linkovi = document.querySelectorAll('nav a');
let trenutnaLokacija = window.location.pathname;

linkovi.forEach(link => {
    if(link.href.includes(trenutnaLokacija)) {
        link.classList.add('pseudo')
    }
})

let s1 = document.getElementById('div1');
let s1s = document.querySelector('.i1');
s1.addEventListener('mouseover', function() {
    s1s.classList.add('hover1')
})
s1.addEventListener('mouseout', function() {
    s1s.classList.remove('hover1')
})


let s2 = document.getElementById('div2');
let s2s = document.querySelector('.i2');
s2.addEventListener('mouseover', function() {
    s2s.classList.add('hover1')
})
s2.addEventListener('mouseout', function() {
    s2s.classList.remove('hover1')
})

let s3 = document.getElementById('div3');
let s3s = document.querySelector('.i3');
s3.addEventListener('mouseover', function() {
    s3s.classList.add('hover1')
})
s3.addEventListener('mouseout', function() {
    s3s.classList.remove('hover1')
})

let s4 = document.getElementById('div4');
let s4s = document.querySelector('.i4');
s4.addEventListener('mouseover', function() {
    s4s.classList.add('hover1')
})
s4.addEventListener('mouseout', function() {
    s4s.classList.remove('hover1')
})


// SLIDER 2
$(".custom-carousel").owlCarousel({
    autoWidth: true,
    loop: true
  });
  $(document).ready(function () {
    $(".custom-carousel .item").click(function () {
      $(".custom-carousel .item").not($(this)).removeClass("active");
      $(this).toggleClass("active");
    });
  });


 



